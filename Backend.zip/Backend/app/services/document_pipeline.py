from app.ai.pdf_converter import convert_pdf_to_images


def process_document(file_path):

    result = {
        "images": [],
        "ocr_text": "",
        "fields": {},
        "trust_score": None
    }

    images = convert_pdf_to_images(
        file_path,
        "temp_images"
    )

    result["images"] = images

    return result