from app.services.document_pipeline import process_document

result = process_document(
    "uploads/TrustIQ_Sample_Company_Document.pdf"
)

print(result)